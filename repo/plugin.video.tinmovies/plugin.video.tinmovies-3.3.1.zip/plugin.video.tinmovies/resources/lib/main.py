# -*- coding: utf-8 -*-
from __future__ import unicode_literals

# noinspection PyUnresolvedReferences
from codequick import Route, Listitem, run
import urlquick


@Route.register
def root(_):
    return from_api()


@Route.register
def show_list(_, url):
    return from_api(url)


def processlist(data):
    for item in data["items"]:
        if "path" in item:
            path = item["path"]
            del item["path"]

            li = Listitem.from_dict(callback="fake://abc", **item)
            li.set_callback(show_list, **path)
            yield li
        else:
            yield Listitem.from_dict(**item)


def from_api(sub_url=None):
    # base_url = u'http://127.0.0.1:8787/kodi/v1'
    base_url = u'https://tinmovies-21xtmq275kk0.deno.dev/kodi/v1'
    # base_url = u'https://tinmovies.deno.dev/kodi/v1'
    if sub_url is not None:
        base_url = base_url + '/' + sub_url
    return processlist(urlquick.get(base_url, max_age=5).json())
