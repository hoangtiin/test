import json
import urllib
from urllib import request


def get_json(url: str, data=None, headers={}):
    return json.loads(request.urlopen(request.Request(url, data, headers)).read())


def get(url: str, data=None):
    try:
        r = request.urlopen(url, data)
    except urllib.error.HTTPError as e:
        r = e

    return r


class NoRedirect(request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


request.install_opener(request.build_opener(NoRedirect))
