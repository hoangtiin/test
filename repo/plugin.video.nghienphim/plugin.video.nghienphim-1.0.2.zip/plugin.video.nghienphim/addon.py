# -*- coding: utf-8 -*-
# Copyright: (c) 2016 - 2030 Hoang Tan
#
# License: GPLv2, see LICENSE for more details
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
import xbmcplugin
import xbmcgui
import xbmc
import json
import sys
import time
import xbmcaddon

import urllib.parse as urlparse

from req import get_json, get


def main():
    handle: int = int(sys.argv[1])
    plugin = sys.argv[0]

    # xbmc.log(json.dumps(sys.argv), xbmc.LOGINFO)

    _, plugin_id, action, raw_params, _ = urlparse.urlsplit(
        sys.argv[0] + sys.argv[2])

    # log(action)

    qs = dict(urlparse.parse_qsl(raw_params))

    subdir = qs.get("subdir", "")

    base_url = 'https://nghienkodi.deno.dev/kodi/jindex.html'

    if subdir != "":
        base_url = base_url + '/' + urlparse.quote(subdir)

    # log(base_url)
    data = get_json(base_url)

    addonFanart = xbmcaddon.Addon().getAddonInfo("fanart")

    try:
        contentType = ""
        defaultFanart = ""
        for item in data["items"]:
            listItem = xbmcgui.ListItem(label=item["label"])

            art = {}
            if "art" in item:
                art = item["art"]
                if defaultFanart == "" and "fanart" in art:
                    defaultFanart = art["fanart"]

                if "fanart" not in art:
                    art["fanart"] = addonFanart

            if "info" in item:
                listItem.setInfo('video', item["info"])
                if contentType == "" and "mediatype" in item["info"]:
                    contentType = item["info"]["mediatype"] + "s"

            isfolder = False
            if "callback" in item:
                listItem.setProperty("IsPlayable", "true")
                listItem.setPath(item["callback"])
            else:
                isfolder = True

            if "icon" not in art:
                art["icon"] = "DefaultFolder.png" if isfolder else "DefaultVideo.png"

            listItem.setArt(art)

            if "path" in item:
                # todo: fix nested object
                subpath = item["path"]["url"]
                plugin = urlparse.urlunsplit(
                    ("plugin", plugin_id, "/" + urlparse.quote(item["label"]), urlparse.urlencode({
                        "subdir": subpath,
                    }), ""))

            xbmcplugin.addDirectoryItem(
                handle, plugin if isfolder else listItem.getPath(), listItem, isfolder)
        if contentType:
            xbmcplugin.setContent(handle, contentType)
        if defaultFanart:
            xbmcplugin.setPluginFanart(handle, defaultFanart)
    finally:
        xbmcplugin.endOfDirectory(handle)


def log(txt: str):
    xbmc.log(txt, xbmc.LOGINFO)


if __name__ == "__main__":
    main()
