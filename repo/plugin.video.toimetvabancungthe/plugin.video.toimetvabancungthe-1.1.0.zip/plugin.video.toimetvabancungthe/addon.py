# -*- coding: utf-8 -*-
# Copyright: (c) 2016 - 2030 Hoang Tan
#
# License: GPLv2, see LICENSE for more details
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
import xbmcplugin
import xbmcgui
import xbmc
import json
import sys
import time
import xbmcaddon

import urllib.parse as urlparse

from resources.lib import urlquick


def main():
    handle: int = int(sys.argv[1])
    plugin = sys.argv[0]

    # xbmc.log(json.dumps(sys.argv), xbmc.LOGINFO)

    _, plugin_id, action, raw_params, _ = urlparse.urlsplit(
        sys.argv[0] + sys.argv[2])

    qs = dict(urlparse.parse_qsl(raw_params))

    if action == "/play":
        play(handle, qs.get("name"), qs.get("backdoor"))
        return

    subdir = qs.get("subdir", "")

    base_url = 'https://aws-lb.deno.dev/kodi/x1'
    # base_url = 'http://127.0.0.1:8787/kodi/x1'

    # log(base_url)

    if subdir != "":
        base_url = base_url + '/' + subdir

    if qs.get("_t"):
        base_url = base_url + "?" + urlparse.urlencode({
            "cursor": qs.get("_t"),
        })

    data = urlquick.get(base_url, max_age=5).json()

    addonFanart = xbmcaddon.Addon().getAddonInfo("fanart")

    try:
        contentType = ""
        defaultFanart = ""
        for item in data["items"]:
            listItem = xbmcgui.ListItem(label=item["label"])

            art = {}
            if "art" in item:
                art = item["art"]
                if defaultFanart == "" and "fanart" in art:
                    defaultFanart = art["fanart"]

                if "fanart" not in art:
                    art["fanart"] = addonFanart

            if "info" in item:
                listItem.setInfo('video', item["info"])
                if contentType == "" and "mediatype" in item["info"]:
                    contentType = item["info"]["mediatype"] + "s"

            isfolder = False
            if "callback" not in item:
                isfolder = True
            else:
                listItem.setProperty("IsPlayable", "true")
                play_qs = urlparse.urlencode({
                    'name': item["label"],
                    'backdoor': item["callback"]
                })

                play_url = urlparse.urlunsplit(
                    ("plugin", plugin_id, "/play", play_qs, ""))
                listItem.setPath(play_url)

            if "icon" not in art:
                art["icon"] = "DefaultFolder.png" if isfolder else "DefaultVideo.png"

            listItem.setArt(art)

            if "path" in item:
                subpath = item["path"]
                plugin = urlparse.urlunsplit(
                    ("plugin", plugin_id, "/", urlparse.urlencode({
                        "_t": round(time.time()),
                        "subdir": subpath,
                    }), ""))

            xbmcplugin.addDirectoryItem(
                handle, plugin if isfolder else listItem.getPath(), listItem, isfolder)
        if contentType:
            xbmcplugin.setContent(handle, contentType)
        if defaultFanart:
            xbmcplugin.setPluginFanart(handle, defaultFanart)
    finally:
        xbmcplugin.endOfDirectory(handle)


def play(handle: int, file_name, url):
    list_item = xbmcgui.ListItem(file_name)
    succeeded = True
    list_item.select(True)
    u = u"&user-agent=" + \
        urlparse.quote(
            u"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36")
    list_item.setPath(urlquick.request(
        "get", url, allow_redirects=False, max_age=5).headers.get("location") + u)
    xbmcplugin.setResolvedUrl(handle, succeeded, list_item)

def log(txt: str):
    xbmc.log(txt, xbmc.LOGINFO)


# from resources.lib import main
if __name__ == "__main__":
    main()

    # main.run()
